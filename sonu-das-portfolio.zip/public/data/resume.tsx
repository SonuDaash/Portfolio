export const resumeData = {
  name: "Sonu Das",
  location: "Birgunj, Nepal",
  phone: "(+977) 9812214979",
  email: "sonudad77@gmail.com",
  linkedin: "www.linkedin.com/in/sonudaas/",
  title: "Experienced School Coordinator & Computer Teacher",
  summary:
    "Dynamic leader with 7+ years of experience streamlining school operations, mentoring educators, and leveraging technology to enhance learning and efficiency.",
  skills: [
    {
      category: "Educational Leadership & Administration",
      items: "School Operations | Staff Supervision | Event & Program Planning | Parent-Teacher Coordination",
    },
    {
      category: "Technology & Digital Tools",
      items: "MS Office | WordPress | Social Media Management | Basic Graphic Design | Video Editing",
    },
    {
      category: "Academic & Exam Coordination",
      items:
        "Curriculum Planning | Assessment & Evaluation | Student Record Management | Classroom Technology Integration",
    },
    {
      category: "Soft Skills",
      items:
        "Leadership | Problem-Solving | Adaptability | Time Management | Team Collaboration | Effective Communication",
    },
  ],
  experience: [
    {
      company: "Royal Academy, Birgunj, Nepal",
      position: "School Coordinator | Computer Teacher",
      period: "01/2078 - Present",
      responsibilities: [
        "Managed and streamlined daily school operations for 700+ students, ensuring efficiency in academic activities.",
        "Supervised and mentored a team of 25+ teachers, fostering professional development and collaboration.",
        "Conducted and facilitated weekly staff meetings to discuss curriculum updates, teaching methodologies, and administrative improvements.",
        "Strengthened parent-teacher relationships through organized conferences, meetings, and transparent communication.",
        "Managed the Integrated Education Management Information System (IEMIS) to centralize student data, ensuring 100% accuracy in enrollment, attendance, and academic reporting for 700+ students.",
        "Maintained student academic records, grades, and performance reports with accuracy and confidentiality.",
      ],
    },
    {
      company: "Birgunj Pathshala, Birgunj, Nepal",
      position: "Exam Coordinator | Computer Teacher",
      period: "02/2074 - 12/2077",
      responsibilities: [
        "Planning and scheduling all academic examinations in accordance with the school curriculum.",
        "Coordinating exam logistics, such as venue, seating, and resources.",
        "Reduced grading errors by 20% by training 15+ invigilators on digital assessment tools.",
        "Managing exam administration processes, such as recording attendance, collecting and organizing completed exam papers, and ensuring timely submission.",
        "Automated report generation using Excel, reducing errors by 40%, and other academic records, as well as managing various technical tasks related to school administration.",
      ],
    },
    {
      company: "Global Business School, Birgunj, Nepal",
      position: "Part-Time Computer Teacher (Class 9 & 10)",
      period: "2079 - 2081",
      responsibilities: [
        "Taught coding fundamentals (HTML/CSS/QBASIC/C++) to 120+ students, focusing on both theoretical knowledge and practical applications.",
      ],
    },
  ],
  education: [
    {
      degree: "Secondary Education Examination (SEE)",
      institution: "Budhanilkhanta Model Community Academy, Kathmandu",
      grade: "3.25",
    },
    {
      degree: "Intermediate (+2)",
      institution: "National Creative Co-Educational School, Kathmandu",
      grade: "3.05 GPA",
    },
    {
      degree: "Bachelor in Business Studies (BBS)",
      institution: "Thakur Ram Multiple Campus, Birgunj",
      grade: "Present",
    },
  ],
  awards: [
    {
      title: "Teacher of the Year - 2075",
      organization: "Birgunj Pathshala",
    },
    {
      title: "Favorite Teacher Award - 2076",
      organization: "Birgunj Pathshala",
    },
  ],
}

