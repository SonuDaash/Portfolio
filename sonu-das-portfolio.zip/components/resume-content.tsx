export default function ResumeContent() {
  return (
    <div className="bg-white text-black p-8 max-w-4xl mx-auto shadow-lg resume-content">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold">Sonu Das</h1>
        <p>Birgunj, Nepal • (+977) 9812214979</p>
        <p>Sonudad77@gmail.com • www.linkedin.com/in/sonudaas/</p>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-bold mb-1">Experienced School Coordinator & Computer Teacher</h2>
        <p className="text-sm">
          Dynamic leader with 7+ years of experience streamlining school operations, mentoring educators, and leveraging
          technology to enhance learning and efficiency.
        </p>
      </div>

      <div className="mb-6">
        <h2 className="text-lg font-bold mb-2 border-b border-gray-300 pb-1">Core Skills</h2>
        <ul className="list-disc pl-6 space-y-1 text-sm">
          <li>
            <span className="font-semibold">Educational Leadership & Administration:</span> School Operations | Staff
            Supervision | Event & Program Planning | Parent-Teacher Coordination
          </li>
          <li>
            <span className="font-semibold">Technology & Digital Tools:</span> MS Office | WordPress | Social Media
            Management | Basic Graphic Design | Video Editing
          </li>
          <li>
            <span className="font-semibold">Academic & Exam Coordination:</span> Curriculum Planning | Assessment &
            Evaluation | Student Record Management | Classroom Technology Integration
          </li>
          <li>
            <span className="font-semibold">Soft Skills:</span> Leadership | Problem-Solving | Adaptability | Time
            Management | Team Collaboration | Effective Communication
          </li>
        </ul>
      </div>

      <div className="mb-6">
        <h2 className="text-lg font-bold mb-2 border-b border-gray-300 pb-1">Professional Experience</h2>

        <div className="mb-4">
          <div className="flex justify-between items-start">
            <h3 className="font-bold">Royal Academy, Birgunj, Nepal</h3>
            <span className="text-sm">01/2078 - Present</span>
          </div>
          <p className="font-medium italic text-sm">School Coordinator | Computer Teacher</p>
          <ul className="list-disc pl-6 mt-1 space-y-1 text-sm">
            <li>Managed and streamlined daily school operations, ensuring efficiency in academic activities.</li>
            <li>
              Supervised and mentored a team of 20+ teachers, fostering professional development and collaboration.
            </li>
            <li>
              Conducted and facilitated weekly staff meetings to discuss curriculum updates, teaching methodologies, and
              administrative improvements.
            </li>
            <li>
              Strengthened parent-teacher relationships through organized conferences, meetings, and transparent
              communication.
            </li>
            <li>
              Spearheaded the integration of technology in classrooms, improving student engagement and learning
              outcomes.
            </li>
            <li>
              Maintained student academic records, grades, and performance reports with accuracy and confidentiality.
            </li>
            <li>
              Handled the IEMIS (Integrated Educational Management Information System) for accurate student data
              management and reporting.
            </li>
          </ul>
        </div>

        <div className="mb-4">
          <div className="flex justify-between items-start">
            <h3 className="font-bold">Birgunj Pathshala, Birgunj, Nepal</h3>
            <span className="text-sm">02/2074 - 12/2077</span>
          </div>
          <p className="font-medium italic text-sm">Exam Coordinator | Computer Teacher</p>
          <ul className="list-disc pl-6 mt-1 space-y-1 text-sm">
            <li>Planned, scheduled, and executed academic examinations aligning with the school curriculum.</li>
            <li>
              Managed logistical aspects of exams, including venue arrangements, seating plans, and resource allocation.
            </li>
            <li>
              Trained and supervised invigilators, ensuring adherence to exam protocols and fairness in assessment.
            </li>
            <li>
              Developed and maintained academic records, ensuring timely report generation for students and faculty.
            </li>
            <li>Implemented innovative assessment methods to evaluate and enhance student learning outcomes.</li>
          </ul>
        </div>

        <div>
          <div className="flex justify-between items-start">
            <h3 className="font-bold">Global Business School, Birgunj, Nepal</h3>
            <span className="text-sm">2079 - Mid 2081</span>
          </div>
          <p className="font-medium italic text-sm">Part-Time Computer Teacher (Class 9 & 10)</p>
          <ul className="list-disc pl-6 mt-1 space-y-1 text-sm">
            <li>
              Delivered engaging computer science lessons, focusing on both theoretical knowledge and practical
              applications.
            </li>
            <li>
              Designed interactive lesson plans and real-world projects to develop students' technical proficiency.
            </li>
            <li>Provided hands-on troubleshooting support, guiding students through technical challenges.</li>
            <li>Assessed student progress through regular evaluations, personalized feedback, and mentorship.</li>
          </ul>
        </div>
      </div>

      <div className="mb-6">
        <h2 className="text-lg font-bold mb-2 border-b border-gray-300 pb-1">Education</h2>
        <ul className="space-y-1 text-sm">
          <li>Secondary Education Examination (SEE) – Budhanilkhanta Model Community Academy, Kathmandu – 3.25</li>
          <li>Intermediate (+2) – National Creative Co-Educational School, Kathmandu – 3.05 GPA</li>
          <li>Bachelor in Business Studies (BBS) – Thakur Ram Multiple Campus, Birgunj – Present</li>
        </ul>
      </div>

      <div>
        <h2 className="text-lg font-bold mb-2 border-b border-gray-300 pb-1">Awards and Achievements</h2>
        <ul className="space-y-1 text-sm">
          <li>Teacher of the Year - 2075 | Birgunj Pathshala</li>
          <li>Favorite Teacher Award - 2076 | Birgunj Pathshala</li>
        </ul>
      </div>
    </div>
  )
}

