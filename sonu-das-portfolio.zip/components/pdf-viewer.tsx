"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Download, FileText, X, ZoomIn, ZoomOut, RotateCw, Printer } from "lucide-react"
import ResumeContent from "./resume-content"

interface PDFViewerProps {
  children: React.ReactNode
  title: string
}

export default function PDFViewer({ children, title }: PDFViewerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [zoom, setZoom] = useState(100)
  const contentRef = useRef<HTMLDivElement>(null)

  // Reset zoom when dialog opens/closes
  useEffect(() => {
    if (!isOpen) {
      setZoom(100)
    } else {
      // When dialog opens, focus on content for keyboard scrolling
      setTimeout(() => {
        if (contentRef.current) {
          contentRef.current.focus()
        }
      }, 100)
    }
  }, [isOpen])

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 25, 200))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 25, 50))
  }

  const handleReset = () => {
    setZoom(100)
    // Reset scroll position when resetting zoom
    if (contentRef.current) {
      contentRef.current.scrollTop = 0
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleDownload = () => {
    // In a real implementation, this would generate and download a PDF
    alert("In a production environment, this would download the resume as a PDF file.")
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-5xl w-full h-[90vh] p-0">
        <div className="flex flex-col h-full">
          <DialogHeader className="px-4 py-2 border-b flex flex-row items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-orange-500" />
              <span>{title}</span>
            </DialogTitle>
            <div className="flex items-center gap-2">
              <div className="hidden md:flex items-center gap-1 mr-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleZoomOut}
                  className="h-8 w-8 border-orange-500/20 hover:bg-orange-500/10 hover:text-orange-500"
                >
                  <ZoomOut className="h-4 w-4" />
                  <span className="sr-only">Zoom Out</span>
                </Button>
                <span className="text-xs font-medium w-12 text-center">{zoom}%</span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleZoomIn}
                  className="h-8 w-8 border-orange-500/20 hover:bg-orange-500/10 hover:text-orange-500"
                >
                  <ZoomIn className="h-4 w-4" />
                  <span className="sr-only">Zoom In</span>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleReset}
                  className="h-8 w-8 border-orange-500/20 hover:bg-orange-500/10 hover:text-orange-500"
                >
                  <RotateCw className="h-4 w-4" />
                  <span className="sr-only">Reset Zoom</span>
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-orange-500/20 hover:bg-orange-500/10 hover:text-orange-500"
                onClick={handlePrint}
              >
                <Printer className="h-4 w-4 mr-1" />
                Print
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-orange-500/20 hover:bg-orange-500/10 hover:text-orange-500"
                onClick={handleDownload}
              >
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="hover:bg-orange-500/10 hover:text-orange-500"
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </Button>
            </div>
          </DialogHeader>
          <div
            ref={contentRef}
            className="flex-1 overflow-auto bg-gray-100 dark:bg-gray-900 p-4 scroll-smooth focus:outline-none"
            tabIndex={0} // Make div focusable for keyboard scrolling
            style={{ scrollBehavior: "smooth" }}
          >
            <div className="flex justify-center min-h-full pb-8">
              <div
                className="bg-white shadow-lg rounded-lg overflow-visible"
                style={{
                  transform: `scale(${zoom / 100})`,
                  transformOrigin: "top center",
                  width: "8.5in",
                  minHeight: "11in",
                  maxWidth: "100%",
                  transition: "transform 0.2s ease-out",
                }}
              >
                <ResumeContent />
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

